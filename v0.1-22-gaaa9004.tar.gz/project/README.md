# Engaslider
## Image Slider Show

![Screenshot of slider](screenshots/screenshot1.jpg)

This source is a simple plugin for create image slide with pure javascript and css.
It implement a basic slide show.


Wandeson Ricardo

Blog: https://wsricardo.blogspot.com

= v0.1 =
